---------------
 libtiled Java
---------------

This is a small library meant to make it easy to use Tiled maps in your Java
project. It is based on the Java version of Tiled.

This small library is LGPL licensed (meaning you can use libtiled-java as-is
in proprietary software, but if you change libtiled-java itself and distribute
it you have to share the source as required by the LGPL). See the COPYING file
for details.

---------
 Authors
---------

Adam Turk <aturk@biggeruniverse.com>
Thorbjørn Lindeijer <thorbjorn@lindeijer.nl>

http://www.mapeditor.org/
